
<form role="search" action="/" id="searchform" method="get" class="form-inline mt-2 mt-md-0 searchform">
     <input type="text" name="s" id="search" value="<?php the_search_query(); ?>"  class="form-control mr-sm-2" placeholder="Search" aria-label="Search" />
		<button class="btn btn-outline-danger my-2 my-sm-0 nav-search" type="submit">Search</button>
</form>

<form role="search" method="get" id="searchform" class="searchform" action="http://localhost/top3sale/">
				<div>
					<label class="screen-reader-text" for="s">Search for:</label>
					<input type="text" value="" name="s" id="s">
					<input type="submit" id="searchsubmit" value="Search">
				</div>
			</form>