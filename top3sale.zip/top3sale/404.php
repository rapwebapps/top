<?php get_header(); ?>
<div class="container-fluid">
    <div id="post-0" class="post error404 not-found">
        <h1 class="entry-title"><?php _e( 'Not Found', 'hbd-theme' ); ?></h1>
        <div class="entry-content">
            <p><?php _e( 'Sorry! You are trying to access a page that <em>does not exist</em>.  So stop, take a deep breath, and think a little.  Maybe you can find what you want by searching.  Maybe you made a typo.  Thank You', 'hbd-theme' ); ?></p>
            <?php get_search_form(); ?>
        </div><!-- .entry-content -->
    </div><!-- #post-0 -->
</div>
<?php get_footer(); ?>