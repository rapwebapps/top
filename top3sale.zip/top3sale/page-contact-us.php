<?php get_header(); ?>	
<main role="main" class="contact">
<div class="container-fluid contact-us">
<div class="form-group">
<h1 class="heading1">Contact us</h1>
	<?php echo do_shortcode( '[contact-form-7 id="17" title="contact us"]' ); ?>

</div>
</div><!-- container -->

<?php get_footer(); ?>	