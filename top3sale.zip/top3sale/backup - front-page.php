<?php get_header(); ?>	
	<main role="main">
	<a href="https://www.amazon.com/gp/goldbox?&_encoding=UTF8&tag=top3sale-20&linkCode=ur2&linkId=39b04c7e79f8206aab3da1b99271bcd5&camp=1789&creative=9325" target="_blank"><img class="banner" src="<?php echo bloginfo('template_url'); ?>/images/banners/top3sale-banner.jpg" alt="Best Deals of the Day"></a>
		<div class="container-fluid">
			<h1 class="main-header bg-light page-title">HOT SELLING ITEMS</h1>
			
			<div class="row">
			<div class="col-lg-3 product-col">
					<div class="product">
											<a href="https://amzn.to/2r15sH6" target="_blank"><h3 class="product-title">Princess Costume Style Bikini</h3></a>
						<a href="https://amzn.to/2r15sH6" target="_blank"><img class="img-thumbnail" alt="Princess-Costume-Style-Bikini" src="<?php echo bloginfo('template_url'); ?>/images/products/Princess-Costume-Style-Bikini.jpg"></a>
						<div class="product-description-cover"><p class="product-description">Impress your friends and be the first to have this adorable like a Dream Princess. This bikini fits true to size and very comfortable, very flattering swimsuit. Available in Snow White, Beauty and the Beast, and Cinderella Style.</p></div>
						<div class="product-details">
							<div class="details">
								<div class="price text-dark">$60</div><img class="img-star" src="<?php echo bloginfo('template_url'); ?>/images/10-star.png"></div>
								<div class="love"><img class="img-love" src="<?php echo bloginfo('template_url'); ?>/images/love-png-black.png"></div><div class="loveit">22 loved it!</div>
							</div>
							<div class="button-link">
							<a href="https://amzn.to/2r15sH6" target="_blank"><input class="detail-link btn-danger rounded" type="button"value="Get This Deal"></input></a>
							</div>
						</div>
				</div><!-- /.col-lg-3 -->
					
										<div class="col-lg-3 product-col">
					<div class="product">
										<div class="oldprice">$699.99</div>
					<div class="off">23% off</div>
					<div class="off-bg rounded-circle"></div>
										<a href="https://amzn.to/2KeWAWk" target="_blank"><h3 class="product-title">Durable Inflatables Bounce House</h3></a>
						<a href="https://amzn.to/2KeWAWk" target="_blank"><img class="img-thumbnail" alt="Durable-Inflatables-Bounce-House" src="<?php echo bloginfo('template_url'); ?>/images/products/Durable-Inflatables-Bounce-House.jpg"></a>
						<div class="product-description-cover"><p class="product-description">Get your own Inflatables that are affordable, safe and fun! Rather than renting, you can have your own Misty Kingdom in your own backyard. It has Water Slide, Splash Pool and Bounce house with free blast zone blower.</p></div>
						<div class="product-details">
							<div class="details">
								<div class="price text-dark">$539.78</div><img class="img-star" src="<?php echo bloginfo('template_url'); ?>/images/9-star.png"></div>
								<div class="love"><img class="img-love" src="<?php echo bloginfo('template_url'); ?>/images/love-png-black.png"></div><div class="loveit">62 loved it!</div>
							</div>
							<div class="button-link">
							<a href="https://amzn.to/2KeWAWk" target="_blank"><input class="detail-link btn-danger rounded" type="button"value="Get This Deal"></input></a>
							</div>
						</div>
				</div><!-- /.col-lg-3 -->
					
										<div class="col-lg-3 product-col">
					<div class="product">
											<a href="https://amzn.to/2JplVfi" target="_blank"><h3 class="product-title">Giant Swimming Pool Float</h3></a>
						<a href="https://amzn.to/2JplVfi" target="_blank"><img class="img-thumbnail" alt="Giant-Swimming-Pool-Float" src="<?php echo bloginfo('template_url'); ?>/images/products/Giant-Swimming-Pool-Float.jpg"></a>
						<div class="product-description-cover"><p class="product-description">Feel the perfect relaxation spot on this thick, soft and durable Leisure Giant Inflatable Unicorn Pool Float. Pleasant and huge with ample of space to de-stress at the beach or pool party for the upcoming summer days!</p></div>
						<div class="product-details">
							<div class="details">
								<div class="price text-dark">$29.99</div><img class="img-star" src="<?php echo bloginfo('template_url'); ?>/images/10-star.png"></div>
								<div class="love"><img class="img-love" src="<?php echo bloginfo('template_url'); ?>/images/love-png-black.png"></div><div class="loveit">12 loved it!</div>
							</div>
							<div class="button-link">
							<a href="https://amzn.to/2JplVfi" target="_blank"><input class="detail-link btn-danger rounded" type="button"value="Get This Deal"></input></a>
							</div>
						</div>
				</div><!-- /.col-lg-3 -->
					
                <div class="col-lg-3 product-col">
					<div class="product">
										<div class="oldprice">$119.99</div>
					<div class="off">47% off</div>
					<div class="off-bg rounded-circle"></div>
										<a href="https://amzn.to/2FdPNsz" target="_blank"><h3 class="product-title">Huge Marine Portable Cooler</h3></a>
						<a href="https://amzn.to/2FdPNsz" target="_blank"><img class="img-thumbnail" alt="Huge-Marine-Portable-Cooler" src="<?php echo bloginfo('template_url'); ?>/images/products/Huge-Marine-Portable-Cooler.jpg"></a>
						<div class="product-description-cover"><p class="product-description">Do not let your ice melt this summer. You will need large well-built and very durable cooler. This cooler is awesome for summer camping, boating trip, etc. and can fit a lot of stuff in it.</p></div>
						<div class="product-details">
							<div class="details">
								<div class="price text-dark">$63.84</div><img class="img-star" src="<?php echo bloginfo('template_url'); ?>/images/9-star.png"></div>
								<div class="love"><img class="img-love" src="<?php echo bloginfo('template_url'); ?>/images/love-png-black.png"></div><div class="loveit">431 loved it!</div>
							</div>
							<div class="button-link">
							<a href="https://amzn.to/2FdPNsz" target="_blank"><input class="detail-link btn-danger rounded" type="button"value="Get This Deal"></input></a>
							</div>
						</div>
				</div><!-- /.col-lg-3 -->
					
										<div class="col-lg-3 product-col">
					<div class="product">
											<a href="https://amzn.to/2K0IDvl" target="_blank"><h3 class="product-title">Infinity War Iron Man Costume</h3></a>
						<a href="https://amzn.to/2K0IDvl" target="_blank"><img class="img-thumbnail" alt="Infinity-War-Iron-Man-Costume" src="<?php echo bloginfo('template_url'); ?>/images/products/Infinity-War-Iron-Man-Costume.jpg"></a>
						<div class="product-description-cover"><p class="product-description">Be one of the superhero team to fight in Avengers: Infinity wearing an exclusive deluxe Iron Man costume for children and adults. Made of pure Polyester with Attached gauntlets, Muscle Chest jumpsuit, boot tops, and mask.</p></div>
						<div class="product-details">
							<div class="details">
								<div class="price text-dark">$32.19</div><img class="img-star" src="<?php echo bloginfo('template_url'); ?>/images/9-star.png"></div>
								<div class="love"><img class="img-love" src="<?php echo bloginfo('template_url'); ?>/images/love-png-black.png"></div><div class="loveit">122 loved it!</div>
							</div>
							<div class="button-link">
							<a href="https://amzn.to/2K0IDvl" target="_blank"><input class="detail-link btn-danger rounded" type="button"value="Get This Deal"></input></a>
							</div>
						</div>
				</div><!-- /.col-lg-3 -->
					
										<div class="col-lg-3 product-col">
					<div class="product">
											<a href="https://amzn.to/2qKPVKM" target="_blank"><h3 class="product-title">Unicorn Color Changing Coffee Mug</h3></a>
						<a href="https://amzn.to/2qKPVKM" target="_blank"><img class="img-thumbnail" alt="Unicorn Color Changing Coffee Mug" src="<?php echo bloginfo('template_url'); ?>/images/products/Unicorn Color Changing Coffee Mug.gif"></a>
						<div class="product-description-cover"><p class="product-description">You will surely love this awesome mug. Make your mornings a bit more magical just pour hot water in and watch the hair change to rainbow color. It made of excellent quality ceramic with really nice packaging perfect for a gift.</p></div>
						<div class="product-details">
							<div class="details">
								<div class="price text-dark">$13.87</div><img class="img-star" src="<?php echo bloginfo('template_url'); ?>/images/9-star.png"></div>
								<div class="love"><img class="img-love" src="<?php echo bloginfo('template_url'); ?>/images/love-png-black.png"></div><div class="loveit">450 loved it!</div>
							</div>
							<div class="button-link">
							<a href="https://amzn.to/2qKPVKM" target="_blank"><input class="detail-link btn-danger rounded" type="button"value="Get This Deal"></input></a>
							</div>
						</div>
				</div><!-- /.col-lg-3 -->
					
										<div class="col-lg-3 product-col">
					<div class="product">
											<a href="https://www.amazon.com/gp/product/B06XRNSHKF/ref=as_li_tl?ie=UTF8&camp=1789&creative=9325&creativeASIN=B06XRNSHKF&linkCode=as2&tag=top3sale-20&linkId=f9c1e5d47784bedbb27f040108740ce0" target="_blank"><h3 class="product-title">Backcountry Camping Sleeping Bag</h3></a>
						<a href="https://www.amazon.com/gp/product/B06XRNSHKF/ref=as_li_tl?ie=UTF8&camp=1789&creative=9325&creativeASIN=B06XRNSHKF&linkCode=as2&tag=top3sale-20&linkId=f9c1e5d47784bedbb27f040108740ce0" target="_blank"><img class="img-thumbnail" alt="product" src="<?php echo bloginfo('template_url'); ?>/images/products/product.jpg"></a>
						<div class="product-description-cover"><p class="product-description">Stay comfortably warm with this cocoon-like shape, the lightest and highest quality Backpacking 4 Season backcountry camping sleeping bag. Make an exceptional choice with the combination of affordability and durability.</p></div>
						<div class="product-details">
							<div class="details">
								<div class="price text-dark">$154.99</div><img class="img-star" src="<?php echo bloginfo('template_url'); ?>/images/10-star.png"></div>
								<div class="love"><img class="img-love" src="<?php echo bloginfo('template_url'); ?>/images/love-png-black.png"></div><div class="loveit">162 loved it!</div>
							</div>
							<div class="button-link">
							<a href="https://www.amazon.com/gp/product/B06XRNSHKF/ref=as_li_tl?ie=UTF8&camp=1789&creative=9325&creativeASIN=B06XRNSHKF&linkCode=as2&tag=top3sale-20&linkId=f9c1e5d47784bedbb27f040108740ce0" target="_blank"><input class="detail-link btn-danger rounded" type="button"value="Get This Deal"></input></a>
							</div>
						</div>
				</div><!-- /.col-lg-3 -->
					
										<div class="col-lg-3 product-col">
					<div class="product">
											<a href="https://www.amazon.com/Magnetics-Building-Colorful-Magnetic-Educational/dp/B07B6NJ4H2/ref=sr_1_14_sspa?s=toys-and-games&ie=UTF8&qid=1523496664&sr=1-14-spons&keywords=toys+and+games&psc=1" target="_blank"><h3 class="product-title">Colorful Magnetic Stick Toys</h3></a>
						<a href="https://www.amazon.com/Magnetics-Building-Colorful-Magnetic-Educational/dp/B07B6NJ4H2/ref=sr_1_14_sspa?s=toys-and-games&ie=UTF8&qid=1523496664&sr=1-14-spons&keywords=toys+and+games&psc=1" target="_blank"><img class="img-thumbnail" alt="Strong Magnet Sticks Games Colorful Magnetic" src="<?php echo bloginfo('template_url'); ?>/images/products/Strong Magnet Sticks Games Colorful Magnetic.jpg"></a>
						<div class="product-description-cover"><p class="product-description">Have a little fun with your family using Colorful Magnetics Toys Building Set Strong Magnet Sticks Games. Magnetics Building set is safe and most suitable for kids homeschool lessons. Let your children be creative and imaginative.</p></div>
						<div class="product-details">
							<div class="details">
								<div class="price text-dark">$20.99</div><img class="img-star" src="<?php echo bloginfo('template_url'); ?>/images/9-star.png"></div>
								<div class="love"><img class="img-love" src="<?php echo bloginfo('template_url'); ?>/images/love-png-black.png"></div><div class="loveit">56 loved it!</div>
							</div>
							<div class="button-link">
							<a href="https://www.amazon.com/Magnetics-Building-Colorful-Magnetic-Educational/dp/B07B6NJ4H2/ref=sr_1_14_sspa?s=toys-and-games&ie=UTF8&qid=1523496664&sr=1-14-spons&keywords=toys+and+games&psc=1" target="_blank"><input class="detail-link btn-danger rounded" type="button"value="Get This Deal"></input></a>
							</div>
						</div>
				</div><!-- /.col-lg-3 -->
					
										<div class="col-lg-3 product-col">
					<div class="product">
											<a href="https://www.amazon.com/Brazilian-Hammock-Outdoor-Backyard-Carrying/dp/B071243BVC/ref=sr_1_10_sspa?ie=UTF8&qid=1523453362&sr=8-10-spons&keywords=outdoor&psc=1" target="_blank"><h3 class="product-title">Durable Soft Cotton Nest Hammock</h3></a>
						<a href="https://www.amazon.com/Brazilian-Hammock-Outdoor-Backyard-Carrying/dp/B071243BVC/ref=sr_1_10_sspa?ie=UTF8&qid=1523453362&sr=8-10-spons&keywords=outdoor&psc=1" target="_blank"><img class="img-thumbnail" alt="Extra Long 2 Person Brazilian Double Hammock Bed" src="<?php echo bloginfo('template_url'); ?>/images/products/Extra Long 2 Person Brazilian Double Hammock Bed.jpg"></a>
						<div class="product-description-cover"><p class="product-description">Excellent outdoor portable hammock. Easy to install and assembled in minutes without any tools needed. Made of the non-fade and softest cotton, you easily sleep in no time. Can be used in balcony, backyard or into the beach.</p></div>
						<div class="product-details">
							<div class="details">
								<div class="price text-dark">$29.95</div><img class="img-star" src="<?php echo bloginfo('template_url'); ?>/images/9-star.png"></div>
								<div class="love"><img class="img-love" src="<?php echo bloginfo('template_url'); ?>/images/love-png-black.png"></div><div class="loveit">98 loved it!</div>
							</div>
							<div class="button-link">
							<a href="https://www.amazon.com/Brazilian-Hammock-Outdoor-Backyard-Carrying/dp/B071243BVC/ref=sr_1_10_sspa?ie=UTF8&qid=1523453362&sr=8-10-spons&keywords=outdoor&psc=1" target="_blank"><input class="detail-link btn-danger rounded" type="button"value="Get This Deal"></input></a>
							</div>
						</div>
				</div><!-- /.col-lg-3 -->
					
										<div class="col-lg-3 product-col">
					<div class="product">
										<div class="oldprice">$199.99</div>
					<div class="off">12% off</div>
					<div class="off-bg rounded-circle"></div>
										<a href="https://www.amazon.com/Mr-Coffee-Barista-Espresso-Cappuccino/dp/B007K9OIMU/ref=lp_289748_1_5?s=kitchen&ie=UTF8&qid=1523434845&sr=1-5" target="_blank"><h3 class="product-title">All-in-1 Coffee Maker</h3></a>
						<a href="https://www.amazon.com/Mr-Coffee-Barista-Espresso-Cappuccino/dp/B007K9OIMU/ref=lp_289748_1_5?s=kitchen&ie=UTF8&qid=1523434845&sr=1-5" target="_blank"><img class="img-thumbnail" alt="Cafe Barista Espresso and Cappuccino Maker" src="<?php echo bloginfo('template_url'); ?>/images/products/Cafe Barista Espresso and Cappuccino Maker.gif"></a>
						<div class="product-description-cover"><p class="product-description">Either you are a coffee lover or new to the world of coffee, you can make your original coffee recipes all from the comfort of your home. Mr. Coffee is semi-automatic so you do not need to be an expert on commercial coffee machines.</p></div>
						<div class="product-details">
							<div class="details">
								<div class="price text-dark">$176.99</div><img class="img-star" src="<?php echo bloginfo('template_url'); ?>/images/9-star.png"></div>
								<div class="love"><img class="img-love" src="<?php echo bloginfo('template_url'); ?>/images/love-png-black.png"></div><div class="loveit">156 loved it!</div>
							</div>
							<div class="button-link">
							<a href="https://www.amazon.com/Mr-Coffee-Barista-Espresso-Cappuccino/dp/B007K9OIMU/ref=lp_289748_1_5?s=kitchen&ie=UTF8&qid=1523434845&sr=1-5" target="_blank"><input class="detail-link btn-danger rounded" type="button"value="Get This Deal"></input></a>
							</div>
						</div>
				</div><!-- /.col-lg-3 -->
					
										<div class="col-lg-3 product-col">
					<div class="product">
											<a href="https://www.amazon.com/Perfect-Drink-Smart-Scale-Recipe/dp/B019C4PUR2/ref=sr_1_14?m=ATVPDKIKX0DER&ie=UTF8&qid=1523434847&sr=8-14" target="_blank"><h3 class="product-title">Your Personal Party Bartender</h3></a>
						<a href="https://www.amazon.com/Perfect-Drink-Smart-Scale-Recipe/dp/B019C4PUR2/ref=sr_1_14?m=ATVPDKIKX0DER&ie=UTF8&qid=1523434847&sr=8-14" target="_blank"><img class="img-thumbnail" alt="Perfect Drink PRO Smart Scale + Recipe App" src="<?php echo bloginfo('template_url'); ?>/images/products/Perfect Drink PRO Smart Scale + Recipe App.jpg"></a>
						<div class="product-description-cover"><p class="product-description">Simple and fun way to Mix Perfect cocktails in your own home. Perfect Drink Pro works like your personal at-home bartender. Mix Drinks like a PRO! for ready-to-go drinks, new cocktails, or have fun play with the great list of drinks.</p></div>
						<div class="product-details">
							<div class="details">
								<div class="price text-dark">$99.99</div><img class="img-star" src="<?php echo bloginfo('template_url'); ?>/images/9-star.png"></div>
								<div class="love"><img class="img-love" src="<?php echo bloginfo('template_url'); ?>/images/love-png-black.png"></div><div class="loveit">8 loved it!</div>
							</div>
							<div class="button-link">
							<a href="https://www.amazon.com/Perfect-Drink-Smart-Scale-Recipe/dp/B019C4PUR2/ref=sr_1_14?m=ATVPDKIKX0DER&ie=UTF8&qid=1523434847&sr=8-14" target="_blank"><input class="detail-link btn-danger rounded" type="button"value="Get This Deal"></input></a>
							</div>
						</div>
				</div><!-- /.col-lg-3 -->
					
										<div class="col-lg-3 product-col">
					<div class="product">
											<a href="https://www.amazon.com/dp/B01N7KFDCW/ref=sspa_dk_detail_0?psc=1&pd_rd_i=B01N7KFDCW&pd_rd_wg=w3rbD&pd_rd_r=AN978JPM7XRNF2JEM9Q6&pd_rd_w=c5JTe" target="_blank"><h3 class="product-title">Angel Wing Necklace Lover's Gifts</h3></a>
						<a href="https://www.amazon.com/dp/B01N7KFDCW/ref=sspa_dk_detail_0?psc=1&pd_rd_i=B01N7KFDCW&pd_rd_wg=w3rbD&pd_rd_r=AN978JPM7XRNF2JEM9Q6&pd_rd_w=c5JTe" target="_blank"><img class="img-thumbnail" alt="Angel Wing Necklace Christmas Gifts" src="<?php echo bloginfo('template_url'); ?>/images/products/Angel Wing Necklace Christmas Gifts.jpg"></a>
						<div class="product-description-cover"><p class="product-description">Send your sweetheart a beautiful gift like Angel Wing Necklace. Nice gift for your Lover, Wife, Fiancee, Girlfriend, Mother on Anniversary or Birthday. Come With A attractive Gift Box ideal for a surprise gift.</p></div>
						<div class="product-details">
							<div class="details">
								<div class="price text-dark">$26.6</div><img class="img-star" src="<?php echo bloginfo('template_url'); ?>/images/9-star.png"></div>
								<div class="love"><img class="img-love" src="<?php echo bloginfo('template_url'); ?>/images/love-png-black.png"></div><div class="loveit">125 loved it!</div>
							</div>
							<div class="button-link">
							<a href="https://www.amazon.com/dp/B01N7KFDCW/ref=sspa_dk_detail_0?psc=1&pd_rd_i=B01N7KFDCW&pd_rd_wg=w3rbD&pd_rd_r=AN978JPM7XRNF2JEM9Q6&pd_rd_w=c5JTe" target="_blank"><input class="detail-link btn-danger rounded" type="button"value="Get This Deal"></input></a>
							</div>
						</div>
				</div><!-- /.col-lg-3 -->
					
										<div class="col-lg-3 product-col">
					<div class="product">
											<a href="https://www.amazon.com/dp/B06Y2B4NWY/ref=sspa_dk_detail_0?psc=1&pd_rd_i=B06Y2B4NWY&pd_rd_wg=NDCH4&pd_rd_r=QN7AFBBH7KXCVMPTXP62&pd_rd_w=bQ9HO" target="_blank"><h3 class="product-title">Norton Core Secure WiFi Router</h3></a>
						<a href="https://www.amazon.com/dp/B06Y2B4NWY/ref=sspa_dk_detail_0?psc=1&pd_rd_i=B06Y2B4NWY&pd_rd_wg=NDCH4&pd_rd_r=QN7AFBBH7KXCVMPTXP62&pd_rd_w=bQ9HO" target="_blank"><img class="img-thumbnail" alt="Norton Core Secure WiFi Router" src="<?php echo bloginfo('template_url'); ?>/images/products/Norton Core Secure WiFi Router.jpg"></a>
						<div class="product-description-cover"><p class="product-description">Replace your unsecured WiFi router and protect your home network with this wonderfully designed Norton Core Wireless Router. Enjoy streaming your favorite movies with additional parental controls and Antivirus security.</p></div>
						<div class="product-details">
							<div class="details">
								<div class="price text-dark">$199</div><img class="img-star" src="<?php echo bloginfo('template_url'); ?>/images/8-star.png"></div>
								<div class="love"><img class="img-love" src="<?php echo bloginfo('template_url'); ?>/images/love-png-black.png"></div><div class="loveit">71 loved it!</div>
							</div>
							<div class="button-link">
							<a href="https://www.amazon.com/dp/B06Y2B4NWY/ref=sspa_dk_detail_0?psc=1&pd_rd_i=B06Y2B4NWY&pd_rd_wg=NDCH4&pd_rd_r=QN7AFBBH7KXCVMPTXP62&pd_rd_w=bQ9HO" target="_blank"><input class="detail-link btn-danger rounded" type="button"value="Get This Deal"></input></a>
							</div>
						</div>
				</div><!-- /.col-lg-3 -->
					
										<div class="col-lg-3 product-col">
					<div class="product">
											<a href="https://www.amazon.com/dp/B071L26GFC/ref=sspa_dk_detail_3?psc=1&pd_rd_i=B071L26GFC&pd_rd_wg=TBgPe&pd_rd_r=T3T1Y0XV0RD68QBXV763&pd_rd_w=KXpyu" target="_blank"><h3 class="product-title">Zenpy Mole Removal Pen</h3></a>
						<a href="https://www.amazon.com/dp/B071L26GFC/ref=sspa_dk_detail_3?psc=1&pd_rd_i=B071L26GFC&pd_rd_wg=TBgPe&pd_rd_r=T3T1Y0XV0RD68QBXV763&pd_rd_w=KXpyu" target="_blank"><img class="img-thumbnail" alt="Zenpy Mole Removal Pen" src="<?php echo bloginfo('template_url'); ?>/images/products/Zenpy Mole Removal Pen.jpg"></a>
						<div class="product-description-cover"><p class="product-description">Zenpy Mole Removal Pen with 3.2 in 10X Handheld Magnifier 6 Strength Levels Professional Beauty Pen for Body Facial Freckle Nevus Warts Age Spot Skin Tag Tattoo Remover with LCD Display</p></div>
						<div class="product-details">
							<div class="details">
								<div class="price text-dark">$27.99</div><img class="img-star" src="<?php echo bloginfo('template_url'); ?>/images/10-star.png"></div>
								<div class="love"><img class="img-love" src="<?php echo bloginfo('template_url'); ?>/images/love-png-black.png"></div><div class="loveit">654 loved it!</div>
							</div>
							<div class="button-link">
							<a href="https://www.amazon.com/dp/B071L26GFC/ref=sspa_dk_detail_3?psc=1&pd_rd_i=B071L26GFC&pd_rd_wg=TBgPe&pd_rd_r=T3T1Y0XV0RD68QBXV763&pd_rd_w=KXpyu" target="_blank"><input class="detail-link btn-danger rounded" type="button"value="Get This Deal"></input></a>
							</div>
						</div>
				</div><!-- /.col-lg-3 -->
					
										<div class="col-lg-3 product-col">
					<div class="product">
										<div class="oldprice">$369</div>
					<div class="off">5% off</div>
					<div class="off-bg rounded-circle"></div>
										<a href="https://www.amazon.com/gp/product/B00X52TWA4/ref=s9u_simh_gw_i5?ie=UTF8&fpl=fresh&pd_rd_i=B00X52TWA4&pd_rd_r=1c5a0a15-318e-11e8-a28c-89c23149c043&pd_rd_w=m2QXO&pd_rd_wg=rOpQX&pf_rd_m=ATVPDKIKX0DER&pf_rd_s=&pf_rd_r=RT5R9E6PCG8TMNSM8Z56&pf_rd_t=36701&pf_rd_p=8f696f0a-3abd-4660-b9bd-1931764e0008&pf_rd_i=desktop" target="_blank"><h3 class="product-title">Brushless High Torque Wrench Kit</h3></a>
						<a href="https://www.amazon.com/gp/product/B00X52TWA4/ref=s9u_simh_gw_i5?ie=UTF8&fpl=fresh&pd_rd_i=B00X52TWA4&pd_rd_r=1c5a0a15-318e-11e8-a28c-89c23149c043&pd_rd_w=m2QXO&pd_rd_wg=rOpQX&pf_rd_m=ATVPDKIKX0DER&pf_rd_s=&pf_rd_r=RT5R9E6PCG8TMNSM8Z56&pf_rd_t=36701&pf_rd_p=8f696f0a-3abd-4660-b9bd-1931764e0008&pf_rd_i=desktop" target="_blank"><img class="img-thumbnail" alt="DEWALT Brushless High Torque Wrench Kit" src="<?php echo bloginfo('template_url'); ?>/images/products/DEWALT Brushless High Torque Wrench Kit.jpg"></a>
						<div class="product-description-cover"><p class="product-description">Ready to be amazed with heavy-duty cordless technology (Wrench toolkit). It comes with a bag and Gift-wrap is also available. This is one of the best tools we ever tested. It has avoid dropping sockets which is an owesome feature.</p></div>
						<div class="product-details">
							<div class="details">
								<div class="price text-dark">$349</div><img class="img-star" src="<?php echo bloginfo('template_url'); ?>/images/10-star.png"></div>
								<div class="love"><img class="img-love" src="<?php echo bloginfo('template_url'); ?>/images/love-png-black.png"></div><div class="loveit">87 loved it!</div>
							</div>
							<div class="button-link">
							<a href="https://www.amazon.com/gp/product/B00X52TWA4/ref=s9u_simh_gw_i5?ie=UTF8&fpl=fresh&pd_rd_i=B00X52TWA4&pd_rd_r=1c5a0a15-318e-11e8-a28c-89c23149c043&pd_rd_w=m2QXO&pd_rd_wg=rOpQX&pf_rd_m=ATVPDKIKX0DER&pf_rd_s=&pf_rd_r=RT5R9E6PCG8TMNSM8Z56&pf_rd_t=36701&pf_rd_p=8f696f0a-3abd-4660-b9bd-1931764e0008&pf_rd_i=desktop" target="_blank"><input class="detail-link btn-danger rounded" type="button"value="Get This Deal"></input></a>
							</div>
						</div>
				</div><!-- /.col-lg-3 -->
					
										<div class="col-lg-3 product-col">
					<div class="product">
										<div class="oldprice">$1249</div>
					<div class="off">12% off</div>
					<div class="off-bg rounded-circle"></div>
										<a href="https://amzn.to/2qHW2QF" target="_blank"><h3 class="product-title">Powerful Gaming Laptop</h3></a>
						<a href="https://amzn.to/2qHW2QF" target="_blank"><img class="img-thumbnail" alt="Powerful Gaming Laptop" src="<?php echo bloginfo('template_url'); ?>/images/products/Powerful Gaming Laptop.jpg"></a>
						<div class="product-description-cover"><p class="product-description">After spending 5 days of researching good reviews and testing gaming laptops we recommend ASUS FX503VM. We are impressed with RAM size and fast CPU plus with the latest Display Technology.This thing does everything!</p></div>
						<div class="product-details">
							<div class="details">
								<div class="price text-dark">$1099</div><img class="img-star" src="<?php echo bloginfo('template_url'); ?>/images/68-star.png"></div>
								<div class="love"><img class="img-love" src="<?php echo bloginfo('template_url'); ?>/images/love-png-black.png"></div><div class="loveit">156 loved it!</div>
							</div>
							<div class="button-link">
							<a href="https://amzn.to/2qHW2QF" target="_blank"><input class="detail-link btn-danger rounded" type="button"value="Get This Deal"></input></a>
							</div>
						</div>
				</div><!-- /.col-lg-3 -->
					
					
			</div><!-- /.row -->
			
		</div><!-- container -->


<?php get_footer(); ?>