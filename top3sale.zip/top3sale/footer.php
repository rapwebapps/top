    <!-- FOOTER -->
      <footer class="bg-dark footer">
	  <div class="container">
	  <div class="row">
		<div class="col-lg-4">
			<div class="f1_menu">
				<ul>
					<h5 class="fh5">Stay updated with the latest and best deals online products from <b>Top3Sale.com</b></h2>
					<li><input class="subs" type="text" placeholder="your@email.com" ></li>
					<li><button type="button" class="btn-subscribe">Subscribe</button></li>
				</ul>
			</div>
		</div><!-- /.col-lg-4 -->
		<div class="col-lg-4">
			<div class="f1_menu">
				<ul>
					<h5 class="fh5">MOST POPULAR</h5>
					<li><a href="category.php?id=47">Gift for Men</a><span class="spacer"></span><a href="category.php?id=49">Gift for Woman</a></li>
					<li><a href="category.php?id=42">Gift for Boys</a><span class="spacer"></span><a href="category.php?id=43">Gift for Girls</a></li>
					<li><a href="category.php?id=67">Gift for Baby</a><span class="spacer"></span><a href="category.php?id=45">Gift for Kids</a></li>
				</ul>
			</div>
		</div><!-- /.col-lg-4 -->
		<div class="col-lg-4">
			<div class="f1_menu">
				<ul>
					<h5 class="fh5">LINKS</h5>
					<li><a href="<?php echo home_url(); ?>/about-us">About us</a></li>
					<li><a href="<?php echo home_url(); ?>/contact-us">Contact us</a></li>
					<!--<li><a href="#">Submit a product</a></li>-->
				</ul>
			</div>
		</div><!-- /.col-lg-4 -->
		
		<div class="row">
		</div><!-- container footer -->
      </footer>
	</main>
	<script src="<?php echo bloginfo('template_url'); ?>/js/jquery-3.2.1.slim.min.js" integrity="" crossorigin="anonymous"></script>
    <script>window.jQuery || document.write('<script src="<?php echo bloginfo('template_url'); ?>/js/jquery-slim.min.js"><\/script>')</script>
    <script src="<?php echo bloginfo('template_url'); ?>/js/popper.min.js"></script>
    <script src="<?php echo bloginfo('template_url'); ?>/js/bootstrap.min.js"></script>
	</body>
</html>