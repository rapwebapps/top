<?php get_header(); ?>	
<main role="main" class="about">
		<div class="container-fluid about-con">
			
		<h1 class="strong">About us</h1>
		<p class="lead">First of all, we want to Thank you for dropping by and we hope you enjoyed yourself, found the product listings informative and helpful.</p>
		<p class="lead">Top3sale is an organization that provides free online product reviews. Our goal is simply to provide our readers the best product they're looking for. We all know that buying products online can be stressful and time-consuming. We are working hard to do the research, test, screen and evaluate the products then we share our thoughts and experiences about it and recommend the best product for you to save time.</p>
			
			<hr class="featurette-divider">
			
		<h2 class="heading-h2">Meet the Team</h2>
		<div class="row ">
			<div class="col-lg-3">
				<div class="team-list">
				<img src="<?php echo bloginfo('template_url'); ?>/images/users/scott.png" alt="Scott Nichols" class="team-photo">
				<p><strong class="team-name">Scotty Nichols</strong></p>
				<span class="team__list-position">Admin</span>
				</div>
			</div>

			<div class="col-lg-3">
				<div class="team-list">
				<img src="<?php echo bloginfo('template_url'); ?>/images/users/matt.png" alt="Matt Binder" class="team-photo">
				<p><strong class="team-name">Matt Binder</strong></p>
				<span class="team__list-position">Support Manager</span>
				</div>
			</div>

			<div class="col-lg-3">
				<div class="team-list">
				<img src="<?php echo bloginfo('template_url'); ?>/images/users/shannon.png" alt="Shannon Frank" class="team-photo">
				<p><strong class="team-name">Shannon Frank</strong></p>
				<span class="team__list-position">Editor</span>
				</div>
			</div>

			<div class="col-lg-3">
				<div class="team-list">
				<img src="<?php echo bloginfo('template_url'); ?>/images/users/dexter.png" alt="Dexter Dela Pena" class="team-photo">
				<p><strong class="team-name">Dexter Dela Pena</strong></p>
				<span class="team__list-position">Software developer</span>
				</div>
			</div>
		</div><!-- /.row -->

		<div class="row ">
			<div class="col-lg-3">
				<div class="team-list">
				<img src="<?php echo bloginfo('template_url'); ?>/images/users/vanessa.png" alt="Vanessa Montgomery" class="team-photo">
				<p><strong class="team-name">Vanessa Montgomery</strong></p>
				<span class="team__list-position">Blogger/Writter</span>
				</div>
			</div>

			<div class="col-lg-3">
				<div class="team-list">
				<img src="<?php echo bloginfo('template_url'); ?>/images/users/rex.png" alt="Rex Chin" class="team-photo">
				<p><strong class="team-name">Rex Chin</strong></p>
				<span class="team__list-position">Blogger/Writter</span>
				</div>
			</div>

			<div class="col-lg-3">
				<div class="team-list">
				<img src="<?php echo bloginfo('template_url'); ?>/images/users/samantha.png" alt="Samantha Matus" class="team-photo">
				<p><strong class="team-name">Samantha Matus</strong></p>
				<span class="team__list-position">Blogger/Writter</span>
				</div>
			</div>

			<div class="col-lg-3">
				<div class="team-list">
				<img src="<?php echo bloginfo('template_url'); ?>/images/users/roberto.png" alt="Roberto Sanchez" class="team-photo">
				<p><strong class="team-name">Roberto Sanchez</strong></p>
				<span class="team__list-position">Blogger/Writter</span>
				</div>
			</div>
			
			<div class="col-lg-3">
				<div class="team-list">
				<img src="<?php echo bloginfo('template_url'); ?>/images/users/linda.png" alt="Linda Ward" class="team-photo">
				<p><strong class="team-name">Linda Ward</strong></p>
				<span class="team__list-position">Blogger/Writter</span>
				</div>
			</div>

			<div class="col-lg-3">
				<div class="team-list">
				<img src="<?php echo bloginfo('template_url'); ?>/images/users/george.png" alt="George Brown" class="team-photo">
				<p><strong class="team-name">George Brown</strong></p>
				<span class="team__list-position">Blogger/Writter</span>
				</div>
			</div>

			<div class="col-lg-3">
				<div class="team-list">
				<img src="<?php echo bloginfo('template_url'); ?>/images/users/sharon.png" alt="Sharon Banks" class="team-photo">
				<p><strong class="team-name">Sharon Banks</strong></p>
				<span class="team__list-position">Blogger/Writter</span>
				</div>
			</div>

			<div class="col-lg-3">
				<div class="team-list">
				<img src="<?php echo bloginfo('template_url'); ?>/images/users/dunrick.png" alt="Dunrick Yetts" class="team-photo">
				<p><strong class="team-name">Dunrick Yetts</strong></p>
				<span class="team__list-position">Blogger/Writter</span>
				</div>
			</div>

			<div class="col-lg-3">
				<div class="team-list">
				<img src="<?php echo bloginfo('template_url'); ?>/images/users/paige.png" alt="Paige Ramey" class="team-photo">
				<p><strong class="team-name">Paige Ramey</strong></p>
				<span class="team__list-position">Blogger/Writter</span>
				</div>
			</div>

			</div><!-- /.row -->
		</div><!-- container -->

<?php get_footer(); ?>	