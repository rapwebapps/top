<?php get_header(); 
$pagename = get_query_var('pagename');  
// query for the about page
$your_query = new WP_Query( 'pagename='.$pagename );
// "loop" through query (even though it's just one page) 
while ( $your_query->have_posts() ) : $your_query->the_post();
//get_the_title();
//the_content();
endwhile;
// reset post data (important!)
wp_reset_postdata();

$post_id = 48;
$post_content = get_post($post_id);
$post_title = $post_content->post_title;
$content = $post_content->post_content;
?>	
	<main role="main" class="container <?php echo $pagename; ?> dynapage">
	<div class="row">
        <div class="col-sm-8 blog-main">
			<div class="blog-post">
            <h2 class="blog-post-title"><?php echo $post_title; ?></h2>
            <p class="blog-post-meta">Last updated on <?php echo get_the_date(); ?></p>
			<p><?php echo $content; ?></p>
			
<hr class="style-eight">
	<?php
	$post_id = 83;
	$post_content = get_post($post_id);
	$post_title = $post_content->post_title;
	$content = $post_content->post_content;
	?>			
		<div class="product">
			<h3 class="product-title text-primary"><?php echo $post_title;?></h3>
			<?php echo $content; ?>
		</div>

<hr class="style-eight">
<?php
$post_id = 91;
$post_content = get_post($post_id);
$post_title = $post_content->post_title;
$content = $post_content->post_content;
?>			
		<div class="product">
			<h3 class="product-title text-primary"><?php echo $post_title;?></h3>
			<?php echo $content; ?>
		</div>
		
		
          </div><!-- /.blog-post -->
        </div><!-- /.blog-main-->
		
		<?php get_sidebar(); ?>
	</main>

<?php get_footer(); ?>	