<?php get_header(); 
$pagename = get_query_var('pagename');  
// query for the about page
$your_query = new WP_Query( 'pagename='.$pagename );
// "loop" through query (even though it's just one page) 
while ( $your_query->have_posts() ) : $your_query->the_post();
//get_the_title();
//the_content();
endwhile;
// reset post data (important!)
wp_reset_postdata();
//page pet
$post_id = 8;
$post_content = get_post($post_id);
$post_title = $post_content->post_title;
$content = $post_content->post_content;
?>	
	<main role="main" class="container <?php echo $pagename; ?> dynapage">
	<div class="row">
        <div class="col-sm-8 blog-main">
			<div class="blog-post">
            <h1 class="blog-post-title"><?php echo $post_title; ?></h1>
            <p class="blog-post-meta">Last updated on <?php echo get_the_modified_date(); ?></p>
			<p><?php echo $content; ?></p>
			
		<hr class="style-eight">
		<?php
		//1
		$post_id = 182;
		$post_content = get_post($post_id);
		$post_title = $post_content->post_title;
		$content = $post_content->post_content;
		?>			
		<div class="product">
			<h3 class="product-title text-primary"><?php echo $post_title;?></h3>
			<?php echo $content; ?>
		</div>

		<hr class="style-eight">
		<?php
		//2
		$post_id = 184;
		$post_content = get_post($post_id);
		$post_title = $post_content->post_title;
		$content = $post_content->post_content;
		?>			
		<div class="product">
			<h3 class="product-title text-primary"><?php echo $post_title;?></h3>
			<?php echo $content; ?>
		</div>
		
		<hr class="style-eight">
		<?php
		//3
		$post_id = 187;
		$post_content = get_post($post_id);
		$post_title = $post_content->post_title;
		$content = $post_content->post_content;
		$contentlink = $post_content->guid;
		?>			
		<div class="product">
			<a href="<?php echo $contentlink; ?>" target="_blank"><h3 class="product-title text-primary"><?php echo $post_title;?></h3></a>
			<?php echo $content; ?>
		</div>

		<hr class="style-eight">
		<?php //4
		$post_id = 189;
		$post_content = get_post($post_id);
		$post_title = $post_content->post_title;
		$content = $post_content->post_content;
		?>			
		<div class="product">
			<h3 class="product-title text-primary"><?php echo $post_title;?></h3>
			<?php echo $content; ?>
		</div>

		<hr class="style-eight">
		<?php //5
		$post_id = 191;
		$post_content = get_post($post_id);
		$post_title = $post_content->post_title;
		$content = $post_content->post_content;
		?>			
		<div class="product">
			<h3 class="product-title text-primary"><?php echo $post_title;?></h3>
			<?php echo $content; ?>
		</div>

		<hr class="style-eight">
		<?php //6
		$post_id = 193;
		$post_content = get_post($post_id);
		$post_title = $post_content->post_title;
		$content = $post_content->post_content;
		?>			
		<div class="product">
			<h3 class="product-title text-primary"><?php echo $post_title;?></h3>
			<?php echo $content; ?>
		</div>

		<hr class="style-eight">
		<?php //7
		$post_id = 195;
		$post_content = get_post($post_id);
		$post_title = $post_content->post_title;
		$content = $post_content->post_content;
		?>			
		<div class="product">
			<h3 class="product-title text-primary"><?php echo $post_title;?></h3>
			<?php echo $content; ?>
		</div>

		<hr class="style-eight">
		<?php //8
		$post_id = 197;
		$post_content = get_post($post_id);
		$post_title = $post_content->post_title;
		$content = $post_content->post_content;
		?>			
		<div class="product">
			<h3 class="product-title text-primary"><?php echo $post_title;?></h3>
			<?php echo $content; ?>
		</div>

		<hr class="style-eight">
		<?php //9
		$post_id = 198;
		$post_content = get_post($post_id);
		$post_title = $post_content->post_title;
		$content = $post_content->post_content;
		?>			
		<div class="product">
			<h3 class="product-title text-primary"><?php echo $post_title;?></h3>
			<?php echo $content; ?>
		</div>

		<hr class="style-eight">
		<?php //10
		$post_id = 134;
		$post_content = get_post($post_id);
		$post_title = $post_content->post_title;
		$content = $post_content->post_content;
		?>			
		<div class="product">
			<h3 class="product-title text-primary"><?php echo $post_title;?></h3>
			<?php echo $content; ?>
		</div>

		<hr class="style-eight">
		<?php //11
		$post_id = 138;
		$post_content = get_post($post_id);
		$post_title = $post_content->post_title;
		$content = $post_content->post_content;
		?>			
		<div class="product">
			<h3 class="product-title text-primary"><?php echo $post_title;?></h3>
			<?php echo $content; ?>
		</div>

		<hr class="style-eight">
		<?php //12
		$post_id = 132;
		$post_content = get_post($post_id);
		$post_title = $post_content->post_title;
		$content = $post_content->post_content;
		?>			
		<div class="product">
			<h3 class="product-title text-primary"><?php echo $post_title;?></h3>
			<?php echo $content; ?>
		</div>

		<hr class="style-eight">
		<?php //13
		$post_id = 129;
		$post_content = get_post($post_id);
		$post_title = $post_content->post_title;
		$content = $post_content->post_content;
		?>			
		<div class="product">
			<h3 class="product-title text-primary"><?php echo $post_title;?></h3>
			<?php echo $content; ?>
		</div>

		<hr class="style-eight">
		<?php //14
		$post_id = 144;
		$post_content = get_post($post_id);
		$post_title = $post_content->post_title;
		$content = $post_content->post_content;
		?>			
		<div class="product">
			<h3 class="product-title text-primary"><?php echo $post_title;?></h3>
			<?php echo $content; ?>
		</div>
<hr class="style-eight">
<h2 class="like-item">YOU MAY ALSO BE INTERESTED IN</h2>
<div class="container like-item-cover">
	
	<div class="row interest">
	
	<?php //15
		$post_id = 136;
		$post_content = get_post($post_id);
		$post_title = $post_content->post_title;
		$content = $post_content->post_content;
		?>			
	<div class="col-lg-4">
		<div class="product">
		<h3 class="product-title"><?php echo $post_title;?></h3>
			<?php echo $content; ?>
		</div>
	</div>

	<?php //16
		$post_id = 140;
		$post_content = get_post($post_id);
		$post_title = $post_content->post_title;
		$content = $post_content->post_content;
		?>			
	<div class="col-lg-4">
		<div class="product">
		<h3 class="product-title"><?php echo $post_title;?></h3>
			<?php echo $content; ?>
		</div>
	</div>
	
	<?php //17
		$post_id = 110;
		$post_content = get_post($post_id);
		$post_title = $post_content->post_title;
		$content = $post_content->post_content;
		?>			
	<div class="col-lg-4">
		<div class="product">
		<h3 class="product-title"><?php echo $post_title;?></h3>
			<?php echo $content; ?>
		</div>
	</div>
	
	</div><!---  like row -->
	</div> <!---  like container -->
		</div><!-- /.blog-post -->
        </div><!-- /.blog-main-->
		
		<?php get_sidebar(); ?>
	</main>

	<?php get_footer(); ?>	