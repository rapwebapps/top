<!doctype html>
<html lang="en">
	<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta name="description" content="Top3SALE is your Online product brochure. You'll see amazing, trending and hot selling products online." ng-if="meta_desc" class="ng-scope">
	<title ng-bind="title" class="ng-binding">Top3SALE :: Cool and unique gift ideas</title>
	<link rel="canonical" href="http://top3sale.com" ng-if="canonical" class="ng-scope">
	<link href="<?php echo bloginfo('template_url'); ?>/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo bloginfo('template_url'); ?>/css/top3.css" rel="stylesheet">
	<link href="<?php echo bloginfo('template_url'); ?>/css/add.css" rel="stylesheet">
	<!-- Custom styles for this template -->
	<link href='https://fonts.googleapis.com/css?family=Artifika' rel='stylesheet'>
	<link href='https://fonts.googleapis.com/css?family=Baloo' rel='stylesheet'>
	<script async src="//pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
	<script>
	  (adsbygoogle = window.adsbygoogle || []).push({
		google_ad_client: "ca-pub-6784499580033232",
		enable_page_level_ads: true
	  });
	</script>
	</head>
	<body>
	<header>
		<nav class="navbar navbar-expand-md bg-light container-fluid">
		<a class="navbar-brand" href="http://top3sale.com/">Top 3 Sale</a>
		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarCollapse" aria-controls="navbarCollapse" aria-expanded="false" aria-label="Toggle navigation"><span class="navbar-toggler-icon"></span></button>
		<div class="collapse navbar-collapse" id="navbarCollapse">
        <?php
            wp_nav_menu( $arg = array ( 'menu_class' => 'navbar-nav mr-auto', 'theme_location' =>  'primary'));
        ?>
		<a class="navbar-brand" href="https://www.amazon.com/gp/goldbox?&_encoding=UTF8&tag=top3sale-20&linkCode=ur2&linkId=39b04c7e79f8206aab3da1b99271bcd5&camp=1789&creative=9325">Best Deals</a>
		</div>
		</nav>
	</header>
