<?php

if (! function_exists ('top3sale_setup')) :

    function top3sale_setup(){
    //let WordPress handle the Titles tags
    add_theme_support('title-tag');
    }
endif;
add_action('after_setup_theme','top3sale_setup');

/** Register Menus **/
function register_top3sale_menus() {
    register_nav_menus(
        array(
        'primary' => __('Primary Menu'),
        'footer' => __('Footer Menu'),
        'sidebar' => __('SideBar Menu')
        )
    );
}
add_action('init', 'register_top3sale_menus');

function top3sale_scripts(){
    //Enqueue Main Stylesheet
    wp_enqueue_style('top3sale_styles', get_stylesheet_uri());
    
    //Enqueue Google Fonts, Raleway
    wp_enqueue_style('top3sale_google_fonts', 'https://fonts.googleapis.com/css?family=Artifika');
}
add_action('wp_enqueue_scripts', 'top3sale_scripts');

/**  Register Widget Areas **/
function top3sale_widget_init(){
    register_sidebar(array(
        'name'=> __('Main Sidebar','top3sale'),
        'id'=>'main-sidebar',
        'description'=> __('Widgets added here will appear in all pages using the two column template', 'top3sale'),
        'before_widget' => '<section id="%1$s" class="Widget %2$s">',
        'after_widget' => '</section>',
        'before_title' => '<h2 class="widget-title">',
        'after_title'=> '</h2>'
    ));
}
add_action ('widgets_init', 'top3sale_widget_init');
