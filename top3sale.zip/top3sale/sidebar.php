
<?php
/* The Template for the Main Sidebar */
?>

<aside class="col-sm-4 ml-sm-auto blog-sidebar">
	<div class="sidebar-module sidebar-module-inset">
<hr class="style-three">
<div class="followus">Follow us
<a href="#" target="_blank"><img class="img-thumbnail" alt="" src="<?php echo bloginfo('template_url'); ?>/images/facebook-icon.png">
<a href="https://twitter.com/top3sale?ref_src=twsrc%5Etfw" target="_blank"><img class="img-thumbnail" alt="" src="<?php echo bloginfo('template_url'); ?>/images/twitter-icon.png">
<a href="#" target="_blank"><img class="img-thumbnail" alt="" src="<?php echo bloginfo('template_url'); ?>/images/youtube-icon.png">
</a>
</div>
<hr class="style-three">

<!--<a href="https://twitter.com/top3sale?ref_src=twsrc%5Etfw" class="twitter-follow-button" data-show-count="false">Follow @top3sale</a><script async src="https://platform.twitter.com/widgets.js" charset="utf-8"></script>
<iframe src="//rcm-na.amazon-adsystem.com/e/cm?o=1&p=12&l=ez&f=ifr&linkID=347ac012572b7646a0496afd0ac0ec6c&t=top3sale-20&tracking_id=top3sale-20" width="300" height="250" scrolling="no" border="0" marginwidth="0" style="border:none;" frameborder="0"></iframe> -->

	</div>
</aside>

<!--/.blog-sidebar <h4>Your Guide</h4>
<p>
<img class="rounded-circle" src="images/users/roberto.png" alt="#" width="45">
Roberto Sanchez
</p>-->
			

<?php //if(is_active_sidebar('main-sidebar')): ?>
<?php //dynamic_sidebar ('main-sidebar');?>
<?php //endif; ?>
<!--<aside class="sidebar widget-area">  </aside>-->

