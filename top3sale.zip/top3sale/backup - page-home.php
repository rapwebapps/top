<?php
/**
 * The template for displaying all pages
 *
 * This is the template that displays all pages by default.
 * Please note that this is the WordPress construct of pages
 * and that other 'pages' on your WordPress site may use a
 * different template.
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.0
 */

get_header(); ?>

<main role="main">
	<a href="https://www.amazon.com/gp/goldbox?&_encoding=UTF8&tag=top3sale-20&linkCode=ur2&linkId=39b04c7e79f8206aab3da1b99271bcd5&camp=1789&creative=9325" target="_blank"><img class="banner" src="<?php echo bloginfo('template_url'); ?>/images/banners/top3sale-banner.jpg" alt="Best Deals of the Day"></a>
		<div class="container-fluid">
			<h1 class="main-header bg-light page-title">HOT SELLING ITEMS</h1>
			<div class="row">


		<?php

		
		$pagename = get_query_var('pagename');  
		   // query for the about page
    $your_query = new WP_Query( 'pagename='.$pagename );
    // "loop" through query (even though it's just one page) 
    while ( $your_query->have_posts() ) : $your_query->the_post();
	
	//var_dump(get_the_category());
	$category_detail=get_the_category();//$post->ID
	foreach($category_detail as $cd){
	if($cd->cat_name == 'Home'){
		?>
		<div class="col-lg-3 product-col">
					<div class="product">
		<?php
		
			get_the_title();
			the_content();
			
			?>
					</div>
				</div><!-- /.col-lg-3 -->

			<?php
			}
	}

    endwhile;
    // reset post data (important!)
    wp_reset_postdata();
		
			?>

	</div><!-- #primary -->
</div><!-- .wrap -->
</main><!-- #main -->
<?php get_footer();
